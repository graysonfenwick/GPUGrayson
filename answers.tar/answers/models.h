//If you want to change the number of bins, the top of the file 
//needs to be commented out and the lines below needs to be uncommented.
//Then type a make and  ./buildHdrs.sh
//After that, re-edit this file to uncomment out the top part 
//and comment out the lines at the bottom

//include the models
//each of these define a histogram
#include "images/Batman1.h"
#include "images/Batman2.h"
#include "images/BlackWidow1.h"
#include "images/BlackWidow2.h"
#include "images/C3PO1.h"
#include "images/C3PO2.h"
#include "images/CaptainAmerica1.h"
#include "images/CaptainAmerica2.h"
#include "images/DarthVader1.h"
#include "images/DarthVader2.h"
#include "images/Flash1.h"
#include "images/Flash2.h"
#include "images/Hawkeye1.h"
#include "images/Hawkeye2.h"
#include "images/Hulk1.h"
#include "images/Hulk2.h"
#include "images/Ironman1.h"
#include "images/Ironman2.h"
#include "images/Ironman3.h"
#include "images/Loki1.h"
#include "images/Loki2.h"
#include "images/Magneto1.h"
#include "images/Magneto2.h"
#include "images/Spiderman1.h"
#include "images/Spiderman2.h"
#include "images/SpidermanVenom1.h"
#include "images/SpidermanVenom2.h"
#include "images/Superman1.h"
#include "images/Superman2.h"
#include "images/Thor1.h"
#include "images/Thor2.h"
#include "images/Wolverine1.h"
#include "images/Wolverine2.h"
#include "images/WonderWoman1.h"
#include "images/WonderWoman2.h"

#define MODELS 35

histogramT * models[MODELS] = {&Batman1, &Batman2, &BlackWidow1,
       &BlackWidow2, &C3PO1, &C3PO2, &CaptainAmerica1, 
       &CaptainAmerica2, &DarthVader1, &DarthVader2, &Hawkeye1, 
       &Hawkeye2, &Flash1, &Flash2, &Hulk1, &Hulk2, &Ironman1, 
       &Ironman2, &Loki1, &Loki2, &Ironman3, &Magneto1, &Magneto2, 
       &Spiderman1, &Spiderman2, &SpidermanVenom1, &SpidermanVenom2, 
       &Superman1, &Superman2, &Thor1, &Thor2, &Wolverine1, &Wolverine2, 
       &WonderWoman1, &WonderWoman2};

/*

//Uncomment this if you want to change the size of the bins and thus
//need to build new models.

#define MODELS 0
histogramT * models[1] = {NULL};

*/



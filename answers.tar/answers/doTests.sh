#!/bin/bash

imageDir="images"
for filename in $imageDir/*.ppm; do
   echo " "
   echo "./classify $filename"
   ./classify $filename
   sleep 1
done

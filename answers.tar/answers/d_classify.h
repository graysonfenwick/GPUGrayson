float d_classify(histogramT * Pout, comparisonT * result, 
                 histogramT ** models, int modelCt, 
                 unsigned char * Pin, int height, int width, 
                 int pitch); 
